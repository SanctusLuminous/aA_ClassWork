require_relative "./piece.rb"
require_relative "./rook.rb"
require_relative "./knight.rb"
require_relative "./bishop.rb"
require_relative "./king.rb"
require_relative "./queen.rb"
require_relative "./pawn.rb"
require_relative "./nullpiece.rb"


class Board

  # row.each  Pawn.new()
# row(0..2) [rook,knight,bishop] k q b k r
#row(5..-1) arr.reverse 
  ROYALS = [Rook, Knight, Bishop, Queen, King, Bishop, Knight, Rook]

  attr_reader :rows

  def load_pawn_row(row, color)
    @rows[row].each_index {|i| self[[row, i]] = Pawn.new(color, self, [row, i])}
  end

  def load_royal_row(row, color)
    ROYALS.each_with_index do |piece_type, i|
      self[[row, i]] = piece_type.new(color, self, [row, i])
    end
  end

  def initialize
    @sentinel = NullPiece.instance
    @rows = Array.new(8) {Array.new(8, @sentinel)}  #@board??
    load_pawn_row(1, :black)
    load_pawn_row(6, :white)
    load_royal_row(0, :black)
    load_royal_row(7, :white)
  end

  def add_piece(piece, position)
    self[position] = piece
  end

  def [](pos)
    row,col = pos
    @rows[row][col]    
  end

  def []=(pos,val)
    row, col = pos
    @rows[row][col] = val
  end

  def move_piece(start_pos, end_pos)
    raise "No piece to move" if self[start_pos] == @sentinel
    raise "Invalid position" unless valid_pos?(end_pos)
    
    piece = self[start_pos]
    raise "Invalid move" if !piece.valid_moves.include?(end_pos) 

    self[end_pos] = self[start_pos]
    self[start_pos] = @sentinel
  end

  def valid_pos?(pos)
    pos.all? {|i| i.between?(0,7)}
  end

  def dup
    @rows.dup
  end

  


end