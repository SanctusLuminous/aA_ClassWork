require_relative 'piece'
require_relative 'stepable'
require 'colorize'

class Knight < Piece
  include Stepable

  def symbol
    '♞'.colorize(color)
  end

  protected

  def move_diffs
    # return an array of diffs representing where a Knight can step to
    steps = [1,-1].product([2,-2]) + [2,-2].product([1,-1])
    steps
  end
end
