require_relative "./piece.rb"


class Pawn < Piece

  def symbol
    '♟︎'.colorize(color)
  end

  def moves
    possible_moves = [[forward_dir, 0], [forward_dir * 2, 0],
                      [forward_dir, 1], [forward_dir, -1]]
    
    moves = []
    possible_moves.each do |dx, dy|
      # if you're not at the start row you can't move more than 1
      next if dx > 1 && !at_start_row?
      row, col = self.pos 
      row += dx
      col += dy 
      space = @board[[row,col]]
      # if you are moving only forward and the space is occupied pass
      next if dy == 0 && !space.empty?
      # if you are moving diagonal check that the space is occupied by other color
      
      if dy != 0
        next if space.empty?
        next if space.color == self.color
      end

      moves << [row,col]
    end
    # at_start_row? ? possible_moves : possible_moves.take(1)

    moves
    #we need a check if its black or white (which is forward_dir) 
    #based on that generate additional diags to check 
    # # if diag say (for white) 1,0 * [0,1], [0,-1]  #[0,1,0,-1] *[ 1,0]
    #run a check if diag11 || diag12  (occupied ) && not the same color  then add <<
  end

  private

  def at_start_row?
    row, col = self.pos
    return (color == :black && row == 1) || (color == :white && row == 6)
  end

  def forward_dir
    color == :black ? 1 : -1
  end

  def side_attacks
    
  end
end

#should have a variable boolean @moved 
# by default @moved is false
#if @moved is false has an extra valid_move 
#so there is an if that makes you chose between two sets of behavior? (while its false it still can go 1 point forawrd)