class Piece
  
  def initialize(color, board, pos)
    @color = color
    @board = board
    @pos = pos
  end

  def to_s
    
  end

  def empty?
    
  end

  def moves
  end

  




end