require_relative "./piece.rb"
class Board

  

  def load_pieces
    @rows[0].each_index {|i| self[[0,i]] = Piece.new(:white, self, [0, i])}
    @rows[1].each_index {|i| self[[1,i]] = Piece.new(:white, self, [1, i])}
    @rows[6].each_index {|i| self[[6,i]] = Piece.new(:black, self, [6, i])}
    @rows[7].each_index {|i| self[[7,i]] = Piece.new(:black, self, [7, i])}
  end
# row.each  Pawn.new()
# row(0..2) [rook,knight,bishop] k q b k r
#row(5..-1) arr.reverse 
  def initialize
    @rows = Array.new(8) {Array.new(8, nil)}  #@board??
    self.load_pieces
      
    # @sentinel = NullPiece.instance
  end

  def add_piece(piece, position)
    self[position] = piece
  end

  def new_diags(current_pos)
    diag1 = [diag3+diag4] #left to righ upwards 
    diag2 = [diag5+diag6]# left to right downwards 
    # diag3  until raise Exception  curr_row, curr_col =currentpos  curr_row +1 curr_col+1 
  def [](pos)
    row,col = pos
    @rows[row][col]    
  end

  def []=(pos,val)
    row, col = pos
    @rows[row][col] = val
  end

  def move_piece(start_pos, end_pos)
    raise "No piece to move" if self[start_pos] == nil
    self[end_pos] = self[start_pos]
    self[start_pos] = nil
  end

  def valid_pos?(pos)
    pos.all? {|i| i.between?(0,7)}
  end

  def dup
    @rows.dup
  end

  


end