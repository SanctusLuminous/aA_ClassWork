module Slideable
  def new_diags(current_pos)
    diag1 = [diag3+diag4] #left to righ upwards 
    diag2 = [diag5+diag6]# left to right downwards 
    # diag3  until raise Exception  curr_row, curr_col =currentpos  curr_row +1 curr_col+1 
end