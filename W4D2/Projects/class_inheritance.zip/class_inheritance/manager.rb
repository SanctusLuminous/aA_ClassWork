require_relative "./employee.rb"

class Manager < Employee
    attr_reader :employees
#{ boss >> [mike(name title salary),jake,]} megahash
    def initialize( name, title, salary, boss =nil )
        super #causes manager to inherit initialization from a class above (Employee)
        @employees = []
    end

    def add_employee(employee)
      self.employees << employee
    end

    def bonus(multiplier)
      sum = 0
      #employee.salary 
      #if employee.is_a?(Manager)

      sum * multiplier
    end

    #bonus = (total salary of all sub-employees) * multiplier
  # { Ned = > N }   
    # daren >>> , "ned" = N 

#    @employees << megahash[name(boss)] 
end

#Shawna	\$12,000	TA	Darren Employee.new("shawna", "TA", )