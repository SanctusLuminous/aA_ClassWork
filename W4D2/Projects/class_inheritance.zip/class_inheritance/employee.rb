class Employee

  def initialize(name, title, salary, boss =nil)
    @name = name
    @title = title
    @boss = boss
    @salary = salary
    
    if !boss.nil? 
      boss.add_employee(self)
    end

  end

  attr_reader :name, :title, :salary, :boss
  def boss=(manager_instance)
  
    @boss = manager_instance
    if manager_instance != nil 
        @boss.add_employee(self)
    end
  end

  def bonus(multiplier)
    bonus = self.salary * multiplier # salary
  end

end
#shana TA 10000 boss= Daren
#daren TAMANAger 20000 boss = ned 